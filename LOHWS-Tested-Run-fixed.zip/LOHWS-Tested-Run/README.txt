LOHWS FRONTEND — BROWSER TEST PACKAGE
=====================================
1. Extract the entire ZIP to a normal Windows folder (e.g. Desktop).
2. Double-click START-LOHWS.bat. Keep its black terminal window open.
3. It starts a local server and opens your default browser.
4. If your browser does not open automatically, copy the printed
   http://127.0.0.1:PORT/index.html into Google Chrome.

Alternatively: Double-click index.html after extraction. If local
file security blocks the app, use START-LOHWS.bat instead.

Do NOT open HTML in the ChatGPT file/workspace preview: that viewer
can show 'Unable to load workspace settings' instead of the app.
Real data/payments are simulated; this is a frontend-only prototype.
