@echo off
setlocal
title LOHWS Local App
cd /d "%~dp0"

if not exist "index.html" (
  echo index.html nahi mila.
  echo Pehle poora ZIP "Extract All" karein, phir is file ko extract kiye hue folder se chalayein.
  echo.
  pause
  exit /b 1
)

rem Try the Python launcher first, then python. Test that it really runs
rem (Windows Store python stub is found by "where" but does not work).
set "PYCMD="
py -3 -c "import sys" >nul 2>nul && set "PYCMD=py -3"
if not defined PYCMD (
  python -c "import sys" >nul 2>nul && set "PYCMD=python"
)

if defined PYCMD (
  %PYCMD% launch.py
  goto end
)

echo Python nahi mila - index.html seedha browser mein khol raha hoon...
start "" "%~dp0index.html"
echo.
echo Agar browser na khule to index.html par double-click karein ya Google Chrome mein drag karein.

:end
echo.
pause
