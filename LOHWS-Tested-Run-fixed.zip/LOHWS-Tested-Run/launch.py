"""Run LOHWS in a local browser using only Python's standard library."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import webbrowser, threading, os, sys

BASE=Path(__file__).resolve().parent
os.chdir(BASE)
class Handler(SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        print(format % args)
class LocalServer(ThreadingHTTPServer):
    allow_reuse_address=True

server=None
for port in (8765,8766,8767,0):
    try:
        server=LocalServer(('127.0.0.1',port),Handler)
        break
    except OSError:
        continue
if server is None:
    print('Server start nahi hua. index.html ko seedha browser mein kholein.')
    webbrowser.open((BASE/'index.html').as_uri())
    sys.exit(1)
url=f'http://127.0.0.1:{server.server_port}/index.html'
print('LOHWS is running at:',url,flush=True)
print('Keep this window open while using the app. Press Ctrl+C to stop.',flush=True)
threading.Timer(0.8,lambda:webbrowser.open(url,new=2)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    print('Closing LOHWS local server.')
finally:
    server.server_close()
